const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Aguardar duas conexões de jogadores
let players = [];
let gameStarted = false;
let positions = {};

// Serve os arquivos estáticos
app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('Novo jogador conectado:', socket.id);

    // Adiciona o jogador à lista
    players.push(socket.id);
    positions[socket.id] = { x: 3, y: 0, shape: getRandomShape() };

    // Envia o ID do jogador para ele
    socket.emit('playerID', socket.id);

    // Quando ambos os jogadores se conectam, inicia o jogo
    if (players.length === 2 && !gameStarted) {
        gameStarted = true;
        io.emit('startGame');
    }

    // Recebe os movimentos dos jogadores e atualiza a posição
    socket.on('move', (moveData) => {
        positions[socket.id] = moveData;
        // Envia para os outros jogadores
        socket.broadcast.emit('move', { playerID: socket.id, moveData });
    });

    // Quando um jogador se desconecta
    socket.on('disconnect', () => {
        console.log('Jogador desconectado:', socket.id);
        players = players.filter(player => player !== socket.id);
        delete positions[socket.id];
        if (players.length < 2) {
            gameStarted = false;
            io.emit('endGame');
        }
    });
});

// Função para gerar uma forma aleatória
function getRandomShape() {
    const shapes = [
        [[1, 1, 1, 1]], // Linha
        [[1, 1], [1, 1]], // Quadrado
        [[0, 1, 0], [1, 1, 1]], // T
    ];
    return shapes[Math.floor(Math.random() * shapes.length)];
}

server.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
